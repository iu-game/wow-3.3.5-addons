﻿-- Author      : LintyDruid

-- Localisation

function HWM_Locale_Spanish()

end