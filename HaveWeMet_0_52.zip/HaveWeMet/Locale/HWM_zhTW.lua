﻿-- Author      : LintyDruid

-- Localisation

function HWM_Locale_Taiwan()

end