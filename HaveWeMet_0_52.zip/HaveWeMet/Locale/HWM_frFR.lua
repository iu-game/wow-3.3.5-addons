﻿-- Author      : LintyDruid

-- Localisation

function HWM_Locale_French()

end
