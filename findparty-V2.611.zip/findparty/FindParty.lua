﻿--GetRealmName(), UnitFactionGroup
BINDING_HEADER_FINDPARTY = "파티찾기 도우미(FindParty)";

local debugSwitch = nil;

FP_Scroll_Info = nil;
FP_Options = nil;
FP_Version = 1;
FP_DUNGEON_LIST = nil;
FP_Filter_Dungeon_Info = nil;
FP_UserDefinedAdMsg = nil;  --from 1.12
FP_Filter_Class = nil;

local FP_Datas = {};
local MAX_VIEW_LINE = 30;
local MIN_VIEW_LINE = 1;
local FP_Exceptions = {};

local FP_OPTION_LIST = {
	[1] = {["광고 주기"] ={"10","20","30","45","60","90","120","300","600"}},
	[2] = {["유효 시간"] ={"30","60", "90","120", "300", "600"}},
	[3] = {["파티찾기 채널"] ={}},
	[4] = {[""] = {}},
	[5] = {["전체 크기"] = {"2","1.9","1.8","1.7","1.6","1.5","1.4",
		"1.3","1.2","1.1","1", "0.9","0.8", "0.7", "0.6",
		"0.5"}
	},
	[6] = {["글자 크기"] = {"12","13", "14","15","16","17","18"}},
	[7] = {["창 색상 편집"] = {}},
	[8] = {[""] = {}},
	[9] = {["던전 편집"] = {}},
	[10] = {[""] = {}},
	[11] = {["초기화"] = {"창 위치", "창 크기"}},
	[12] = {[""] = {}},
	[13] = {["귀속던전 제외"] = {}},
	[14] = {["ESC로 창 닫기"] = {}},
};

local FP_OPTION_NAME = {
	["광고 주기"] = "interval" ,
	["유효 시간"] = "valid"  ,
	["파티찾기 채널"] = "channel",
	["전체 크기"] = "scale",
	["글자 크기"] = "fontsize",
	["초기화"] = "reset",
	["창 색상 편집"] = "color",
	["귀속던전 제외"] = "belong",
	["ESC로 창 닫기"] = "esc",
};

local Party_Find_Info = {
	["class"]={},
	["mode"] = "일반",
	["dungeon"] = "던전을 선택해주세요",
	["selected"] = false,
	["announcing"] = false,
	--["userdefine"] = false,
	--["userdefineWh"] = false,
};

local ShouterSelected = nil;

local ASCD = true;
local DESC = false;

local INC = 1;
local DEC = 2;
local MAX = 3;
local MIN = 4;

local FP_Sort_Info = {
	["time"] = ASCD,
	["dungeon"] = ASCD,
	["name"] = ASCD,
	["msg"] = ASCD,
	["current_sort"] ="dungeon"
};

local Col_Name = {"time", "dungeon", "name", "msg"}



local valdating_timer = 0;
local announce_timer = 0;

local User_Realm;
local User_Faction;

local FP_Default_Options= {
	["interval"] = 30,
	["valid"] = 60,
	["channel"] = { ["파티"] = true },
	["activated"] = true;
	["scale"] = 1,
	["fontsize"] = 13,
	["iconLocked"] = false,
	["color"] = { ["r"] = 0, ["g"] = 0, ["b"] = 0, ["opacity"] = 0.5, },
	["titlebarVisible"] = true,
	["menubarVisible"] = true,
	["activateBellnWindow"] = true,
};

local InfoDepository = {};

function FP_Init()
	FP_Debug("Init");
	FP_Debug("Version "..tostring(FP_Version).." / "..tostring(FP_CURRENT_VERSION));

	FP_GetChannels();

	if (not (FP_Version == FP_CURRENT_VERSION)) then
		FP_Debug("--  New version Init");
		local oldOption = FP_Options;

		FP_Options = {};
		for k,v in pairs(FP_Default_Options) do
			FP_Options[k] = v;
		end
		FP_Options.channel = {};
		for k,v in pairs(FP_Default_Options.channel) do
			FP_Options.channel[k] = v;
		end
		FP_Options.color = {};
		for  k,v in pairs(FP_Default_Options.color) do
			FP_Options.color[k] = v;
		end

		if (oldOption) then
			for k,v in pairs(oldOption) do
				FP_Debug("Old option "..k.." / "..tostring(v));
				if (FP_Options[k] and type(FP_Options[k]) == type(v)) then
					FP_Options[k] = v;
				end
			end
		end

		local oldScroll = FP_Scroll_Info;
		if (oldScroll) then
			for k, v in pairs(oldScroll) do
				FP_Scroll_Info[k] = v;
			end
		else
			FP_Scroll_Info = {
				["max"] = MAX_VIEW_LINE,
				["height"] = 25,
				["viewLines"]=MAX_VIEW_LINE,
			};
		end

		-- 던전리스트 변경으로 인한 버전변경(강제로 던전리스트 초기화)
		if (not FP_DUNGEON_LIST or FP_Version < 2.6) then
			DEFAULT_CHAT_FRAME:AddMessage("|cffff0000FindParty - 구 버전 발견! 던전 리스트를 초기화 합니다.");
			FP_LoadDefaultDungeonList();
		end
		-- from 1.12
		FP_Filter_Dungeon_Info = {
			["filtered"] = false,
			["zones"] = {},
			["dungeons"] = {},
			["num"] = 0;
		}

		-- from 1.12
		FP_Filter_Class = "모두";
		FP_Version = FP_CURRENT_VERSION;
	end

	-- FP_RAID_ORDER 과 FP_DUNGEON_LIST의 항목이 일치하는지 체크 - 실패하면 던전 리스트를 초기화 한다 (오류 방지를 위해) by 영원이란
	local order_check1 = 0;
	local order_check2 = 0;
	
	for k, v in pairs(FP_RAID_ORDER) do
		order_check1 = order_check1 + 1;
		for c, n in pairs(FP_DUNGEON_LIST["공격대"]) do
			if (v == c) then
				order_check2 = order_check2 + 1;
			end
		end
	end
	
	if (order_check1 ~= order_check2) then
		DEFAULT_CHAT_FRAME:AddMessage("|cffff0000FindParty - 던전 목록 체크 실패! 던전 리스트를 초기화 합니다.");
		FP_LoadDefaultDungeonList();
	end

	--FP_OPTION_LIST["던전 편집"] = FP_DUNGEON_LIST;

	User_Realm = GetRealmName();
	User_Faction = UnitFactionGroup("player");

	FP_ListResize();
	FP_UIResize(FP_Options.scale);
	FP_FontResize();
	FP_SetListColor();

	FP_Activate(FP_Options.activated);

	if(FP_IsActiveBellnWindow()) then
		FP_TitleFrameActivateBellnWindow:SetNormalTexture("Interface\\AddOns\\FindParty\\bellActivated");
	else
		FP_TitleFrameActivateBellnWindow:SetNormalTexture("Interface\\AddOns\\FindParty\\bellDeactivated");
	end

	-- 타이틀바, 메뉴바 설정
	if (FP_Options.titlebarVisible) then
		FP_TitleFrame:Hide();
	else
		FP_TitleFrame:Show();
	end
	FP_ListFrameBridgeToTitle:GetScript("OnClick")();

	if (FP_Options.menubarVisible) then
		FP_MenuFrame:Hide();
	else
		FP_MenuFrame:Show();
	end
	FP_ListFrameBridgeToMenu:GetScript("OnClick")();

	--광고글 설정
	if (FP_UserDefinedAdMsg) then
		FP_FindFrameAdText:SetText(FP_UserDefinedAdMsg);
		if(FP_Options.userdefine) then FP_FindFrameEtc:SetChecked(true); end
	end
	if (FP_UserDefinedWhMsg) then
		FP_FindFrameWhText:SetText(FP_UserDefinedWhMsg);
		if(FP_Options.userdefineWh) then FP_FindFrameWhCheck:SetChecked(true); end
	end
	
	-- 던전선택 설정
	FP_ListFrameFilterDungeonText:SetText("던전: "..FP_GetDungeonFilterDesc());

	-- 클래스선택 설정
	FP_ListFrameFilterClassText:SetText("직업 골라내기 : "..FP_Filter_Class);

	if( FP_Options[FP_OPTION_NAME["ESC로 창 닫기"]] ) then
		tinsert(UISpecialFrames, "FP_Frame");
	end;
end

function FP_Activate(active)
	FP_Options.activated = active;

	if (active) then
		FP_TitleFrameText:SetText(FP_C_TITLE);
		FP_TitleFrameActivation:SetNormalTexture("Interface\\AddOns\\FindParty\\activated");

		-- 재시작시 데이타 초기화
		FP_RemoveAllList();
		FP_Scroll();
	else
		FP_TitleFrameText:SetText(FP_C_TITLE.." (중단)");
		FP_TitleFrameActivation:SetNormalTexture("Interface\\AddOns\\FindParty\\deactivated");
		collectgarbage("collect");
	end
end

function FP_ActiveBellnWindow(active)
	if(active) then
		FP_Options["activateBellnWindow"] = false;
		FP_TitleFrameActivateBellnWindow:SetNormalTexture("Interface\\AddOns\\FindParty\\bellDeactivated");
	else
		FP_Options["activateBellnWindow"] = true;
		FP_TitleFrameActivateBellnWindow:SetNormalTexture("Interface\\AddOns\\FindParty\\bellActivated");
	end
	
end

function FP_CreateNewShoutingInfo()
	local info;
	local num = #InfoDepository;
	if (num > 0) then
		info = InfoDepository[num];
		table.remove(InfoDepository, num);
	else
		info ={["name"]= nil,
			["class"] = nil,
			["level"] = nil,
			["msg"] = nil,
			["time"] = 0,
			["dungeon"]= nil,
			["mode"]= nil,
			["user"]= nil,
		};
	end

	return info;
end

function FP_RestoreShoutingInfo(info)
	table.insert(InfoDepository, info);
end

function FP_GetChannels()
	FP_OPTION_LIST[3]["파티찾기 채널"] = {};

	for i=1, 20 do
		local id, name = GetChannelName(i);
		if (id and name) then
			table.insert(FP_OPTION_LIST[3]["파티찾기 채널"], tostring(name));
		end
	end
end

function FP_DungeonParse(msg)
	local dungeon = nil;
	local mode = "일반";
	local FP_dungeon_check = 1;
	local FP_MODE_check = true;
	local dungeon_status = nil;

	FP_Debug("msg : "..msg)
	for zone,dlist in pairs(FP_DUNGEON_LIST) do
		FP_Debug("zone"..zone);
		-- for in pairs문으로 리스트를 불러들일때 랜덤이라서.. 공격대 던전 모집의 경우 여러가지가 겹치니 (ex:마그 막공 모집시 카라잔 이상템..)
		if zone ~= "공격대" then
			FP_Debug("==========="..zone.."============");
			for v,k in pairs(dlist) do
				for i=1, table.getn(k) do
					FP_Debug("+++"..k[i])
					if (string.find(msg, k[i])) and FP_dungeon_check then
						
						dungeon = v;
 							
						FP_Debug("dungeon :: "..tostring(dungeon));
						FP_dungeon_check = nil;
						
						dungeon_status = "5인던전";
					end
				end
			end
		else
			FP_Debug("----------"..zone.."------------");
			for k=1, table.getn(FP_RAID_ORDER) do
				FP_Debug("FP_RAID_ORDER["..k.."]")
				for n = 1, table.getn(dlist[FP_RAID_ORDER[k]]) do
					FP_Debug(">>>"..dlist[FP_RAID_ORDER[k]][n]..tostring(FP_dungeon_check))
					if (string.find(msg, dlist[FP_RAID_ORDER[k]][n])) and FP_dungeon_check then
						-- 추가 필터링 by 영원이란 (스팩 관련 문자 최대한 제거)
						if (string.find(msg, dlist[FP_RAID_ORDER[k]][n].."급") or string.find(msg, dlist[FP_RAID_ORDER[k]][n].." 급")
							or string.find(msg, dlist[FP_RAID_ORDER[k]][n].."이상") or string.find(msg, dlist[FP_RAID_ORDER[k]][n].." 이상")
							or string.find(msg, dlist[FP_RAID_ORDER[k]][n].."스팩") or string.find(msg, dlist[FP_RAID_ORDER[k]][n].." 스팩")
							or string.find(msg, dlist[FP_RAID_ORDER[k]][n].."스펙") or string.find(msg, dlist[FP_RAID_ORDER[k]][n].." 스펙")
							or string.find(msg, dlist[FP_RAID_ORDER[k]][n].."파밍") or string.find(msg, dlist[FP_RAID_ORDER[k]][n].." 파밍")
						) then
						else
							dungeon = FP_RAID_ORDER[k];
							FP_dungeon_check = nil;
							dungeon_status = "공격대던전";
						end
					end
				end
			end
			-- 주간 퀘스트 판단을 위한 추가 by 영원이란 (주간 퀘스트 관련 문자열이 들어가면 무조건 주간 퀘스트로 분류)
			if(string.find(msg, "주간")) then dungeon = "주간 퀘스트"; end 
			if(string.find(msg, "주퀘")) then dungeon = "주간 퀘스트"; end
		end
	end
	FP_Debug(">>>>dungeon : "..tostring(dungeon));
	for k=1, table.getn(FP_DUNGEON_MODE_ORDER) do
		for n = 1, table.getn(FP_DUNGEON_MODE[FP_DUNGEON_MODE_ORDER[k]]) do
			if (string.find(msg, FP_DUNGEON_MODE[FP_DUNGEON_MODE_ORDER[k]][n])) and FP_MODE_check then
				
				mode = FP_DUNGEON_MODE_ORDER[k];
				
				if( dungeon_status=="공격대던전" ) then

					if( mode=="일반" ) then mode="10인"; end
					if( mode=="영웅" ) then mode="25인"; end

				end
				
				if(string.find(msg, "하드")) then mode = mode.." 영웅"; end	-- 하드 모드의 메시지 조합이 너무 많아서 하드라는 글자만 있으면 하드로 강제 셋팅 2009.09.08 edited by 일분일초 - 스톰레이지
				
				FP_Debug("mode :: "..mode)
				FP_Debug(FP_DUNGEON_MODE[FP_DUNGEON_MODE_ORDER[k]][n]);
				FP_MODE_check = nil;
			end
		end
	end
	FP_Debug(">>>>>dungeon : "..tostring(dungeon));

	-- 묶이지 않았을 경우만 작동하도록 수정 변경 2009.05.23 edited by 일분일초 - 스톰레이지
	if (dungeon and mode) then
		for j=1, GetNumSavedInstances() do
			local name, id, remaining, difficulty, locked, extended, instanceIDMostSig, isRaid = GetSavedInstanceInfo(j);
			FP_Debug(name.." "..difficulty.." "..tostring(locked).." "..tostring(extended).." "..tostring(instanceIDMostSig).." "..tostring(isRaid));
			FP_Debug(tostring(dungeon).." "..tostring(FP_DUNGEON_NUM[mode]));

			if (FP_Options[FP_OPTION_NAME["귀속던전 제외"]] and name == dungeon and difficulty == FP_DUNGEON_NUM[mode]) then
				FP_Debug("귀속!!!??? : "..remaining);
--				if remaining == 0 then return dungeon, mode; end -- 인던 중 만료된 인던인 경우 작동 2009.08.17 edited by 호드머리 - 달라란
				if locked == false then return dungeon, mode; end -- 귀속정보 함수에서 뽑아냈어도 귀속되지 않은 함수가 있음.(버그인듯) 이 경우 해당 인스턴스 정보로부터 귀속 여부를 판단하여 비 귀속시 작동시킴 2009.10.05 edited by 일분일초 - 스톰레이지
--				if (string.find(msg, id)) then return dungeon, "귀속"; end	-- 묶였을 경우 묶인 던전 id가 메시지에 있을 경우 작동  2009.05.27 edited by 일분일초 - 스톰레이지
				dungeon = nil;
				mode = nil;
			end
		end
	end
	FP_Debug(">>>>>>dungeon : "..tostring(dungeon));
	-- 던전 및 모드값이 없어도 묶인 id값이 msg에 있으면 귀속던전 제외에서 예외적으로 작동하도록 추가 2009.05.25 by 일분일초 - 스톰레이지
	for i=1, GetNumSavedInstances() do
		local name, id, remaining, difficulty = GetSavedInstanceInfo(i);
		if (string.find(msg, id)) then return "귀속된 던전 ID", "귀속"; end	-- 묶였을 경우 묶인 던전 id가 메시지에 있을 경우 작동
	end	
	FP_Debug(">>>>>>>dungeon : "..tostring(dungeon));
	if(dungeon and string.find(dungeon, "일퀘")) then mode="일퀘"; end
	FP_Debug("|cffff0000■■■■■■|r"..tostring(dungeon).."|cffff0000■■■■■■|r"..tostring(mode))
	return  dungeon, mode;

--	for v,k in pairs(FP_DUNGEON_MODE) do
--		if (string.find(msg, v)) then
--			mode = v;
--		else
--			for i=1, table.getn(k) do
--				if (string.find(msg, k[i])) then
--					mode = v;
--					FP_Debug("mode : "..mode)
--					break;
--					return  dungeon, mode;
--				end
--			end
--		end
--	end

--	return  dungeon, mode;
end

function FP_FP_Filter_Class(msg, class, mode)
	FP_Debug("|cffff0000■■■■■■FP_FP_Filter_Class Start|r");
	if (class=="모두") then return true; end
	--귀속 및 일퀘 분류 삭제에 따른 주석 처리 by 영원이란
	--if (mode=="귀속" or mode=="일퀘") then return true; end		-- 클래스 상관 없는 항목.. mode는 FP_DungeonParse 메소드에서 변형한 것임. 2009.05.27 edited by 일분일초 - 스톰레이지
	FP_Debug("Filtering : "..msg)
	for i=1, table.getn(FP_CLASS_LIST[class]) do
		FP_Debug("Filtered by "..FP_CLASS_LIST[class][i]);
		if (string.find(msg, FP_CLASS_LIST[class][i])) then
			return true;
		end
	end
	FP_Debug("|cffff0000■■■■■■FP_FP_Filter_Class End|r");
	return false;
end

function FP_DungeonFilter(dungeon, mode)
	FP_Debug("|cffff0000■■■■■■FP_DungeonFilter Start|r");
	FP_Debug(dungeon);
	FP_Debug(mode);
	FP_Debug(FP_Filter_Dungeon_Info.dungeon);
	FP_Debug(FP_Filter_Dungeon_Info.mode);
	FP_Debug(FP_Filter_Dungeon_Info.filtered);
	--if (mode=="귀속") then return true; end	-- 귀속 던전인 경우 어떤 던전이든 상관없이 true. 2009.05.27 edited by 일분일초 - 스톰레이지
	if (FP_Filter_Dungeon_Info.filtered) then
-- 		필터링 함수 수정 by 영원이란
--		if (FP_Filter_Dungeon_Info.dungeons["ALL"]) then
--			return FP_Filter_Dungeon_Info.dungeons["ALL"].mode == mode;
--		else
		for d, m in pairs(FP_Filter_Dungeon_Info.dungeons) do
			if (dungeon == d) then
				for k, v in pairs(FP_Filter_Dungeon_Info.dungeons[d]) do
					if ((k == mode) and (v == true)) then
						return true;
					end
				end
--					if (m.mode == "전체") then
--						return true;
--					else
--						return m.mode == mode;
--					end
			end
		end
		return false;
--		end
	end
	FP_Debug("|cffff0000■■■■■■FP_DungeonFilter End|r");
	return true;
end

function FP_ExceptionFilter(exception)
	FP_Debug("Filtering");
	FP_Debug(dungeon);
	FP_Debug(mode);
	FP_Debug(FP_Filter_Dungeon_Info.dungeon);
	FP_Debug(FP_Filter_Dungeon_Info.mode);
	--ShouterSelected.name
	if (FP_Exceptions) then
		for i=1,#FP_Exceptions,1 do
			if (FP_Exceptions[i]==exception) then
				return false;
			end
		end
	end
	return true;
end

function FP_AddList(name, msg)
	FP_Debug("FP_AddList");
	FP_Debug("msg : "..msg);
	-- 던전명과 난이도를 알아낸다
	local dungeon, mode = FP_DungeonParse(msg);
	FP_Debug(">>>>>>>>"..tostring(dungeon)..tostring(mode));
	if (dungeon) then
		FP_Debug("dungeon : name - "..dungeon.." : "..name);
		if (FP_Datas[name]) then
			FP_Datas[name].dungeon = dungeon;
			FP_Datas[name].msg = msg;
			FP_Datas[name].time = 0;
			FP_Datas[name].mode = mode;
		else
			local info = FP_CreateNewShoutingInfo();
			info.name=name;
			info.class = nil;
			info.level = nil;
			info.msg = msg;
			info.time = 0;
			info.dungeon = dungeon;
			info.mode = mode;

			--for using Prat (제거됨)
			--[[
			if (PratDB) then
				if (not User_Realm) then
					User_Realm = GetRealmName();
					User_Faction = UnitFactionGroup("player");
				end

				if (User_Realm) then
					local dbTable = tostring(User_Realm).." - "..tostring(User_Faction);

					if (PratDB.namespaces.PlayerNames.realms[dbTable]
						and PratDB.namespaces.PlayerNames.realms[dbTable].classes
						and PratDB.namespaces.PlayerNames.realms[dbTable].levels)
					then
						info.class = PratDB.namespaces.PlayerNames.realms[dbTable].classes[name];
						info.level = PratDB.namespaces.PlayerNames.realms[dbTable].levels[name];
					end
				end

				FP_Debug(name.." > "..tostring(info.class).." / "..tostring(info.level));
			end
			if (Prat_PlayerNames and Prat_PlayerNames.Levels and Prat_PlayerNames.Classes) then
				info.level = Prat_PlayerNames.Levels[name];
				info.class = Prat_PlayerNames.Classes[name];
			end
			]]--
			table.insert(FP_Datas,info);
			FP_Datas[name] = info;
		end
		FP_Scroll();
	end
end

function FP_RemoveList(name)
	if (FP_Datas[name]) then
		if (ShouterSelected and ShouterSelected.name == name) then
			ShouterSelected = nil;
		end

		for i=1, table.getn(FP_Datas) do
			FP_Debug("i = "..i.." / "..table.getn(FP_Datas).."  name = "..FP_Datas[i].name.." / "..name);
			if (FP_Datas[i].name == name) then
				FP_Debug("Matched");
				FP_RestoreShoutingInfo(FP_Datas[i]);
				table.remove(FP_Datas, i);
				break;
			end
		end
		FP_Datas[name] = nil;
		--collectgarbage("collect");
		FP_Scroll();
	end
end

function FP_RemoveAllList()
    FP_Datas = {};
    ShouterSelected = nil;
    InfoDepository = {};

    collectgarbage("collect");
end

function FP_Refresh(quick)
	FP_Debug("|cffff0000■■■■■■FP_Refresh Start|r");
	local listOffset = FauxScrollFrame_GetOffset(FP_ListFrameScrollFrame);
	if (not listOffset) then listOffset = 0; end

	if (not quick)  then
		local sort_col = FP_Sort_Info.current_sort;
		local ascd = FP_Sort_Info[sort_col];

		FP_ListSort(FP_Datas, sort_col, ascd);
	end

	local dataIdx =listOffset + 1;
	local rowIdx = 1;
	while (rowIdx <= MAX_VIEW_LINE) do
		FP_Debug("while");
		FP_Debug("row ="..rowIdx.." data ="..dataIdx);

		local rowName ="FP_ListFrameRow"..tostring(rowIdx);
		local info = nil;
		if (rowIdx <= FP_Scroll_Info.viewLines) then
			info = FP_Datas[dataIdx];
		end

		FP_Debug("info "..tostring(info));

		if (info) then
			FP_Debug("FP_DungeonFilter-FP_FP_Filter_Class-FP_ExceptionFilter :: "..tostring(FP_DungeonFilter(info.dungeon, info.mode)).."-"..tostring(FP_FP_Filter_Class(info.msg, FP_Filter_Class)).."-"..tostring(FP_ExceptionFilter(info.name)));
			if (not FP_DungeonFilter(info.dungeon, info.mode) or not FP_FP_Filter_Class(info.msg, FP_Filter_Class, info.mode) or not FP_ExceptionFilter(info.name)) then
				getglobal(rowName):Hide();
				rowIdx = rowIdx - 1;
				FP_Scroll_Info.max = FP_Scroll_Info.max - 1;
				FauxScrollFrame_Update(FP_ListFrameScrollFrame,
				FP_Scroll_Info.max,
				FP_Scroll_Info.viewLines,
				FP_Scroll_Info.height);
				if (info == ShouterSelected) then ShouterSelected = nil; end
			else
				if(info.time<=0) then
					if(FP_Options["activateBellnWindow"]) then
						PlaySoundFile("Interface\\AddOns\\FindParty\\FindParty.wav");
						FP_Frame:Show();
						info.time=1;
					end
				end
				getglobal(rowName):Show();
				getglobal(rowName):SetID(dataIdx);
				-- Time
				getglobal(rowName.."TimeText"):SetText(info.time);

				--Message
				local msg = info.msg;
				for class, alias in pairs(FP_CLASS_LIST) do
					for i=1, getn(alias) do
						msg = string.gsub(msg, alias[i], "|cffffff00"..alias[i].."|r");
					end
				end

				getglobal(rowName.."MsgText"):SetText(msg);

				getglobal(rowName.."DungeonText"):SetText(info.dungeon);

				-- 색처리 세분화 / 수정
				if (info.mode == "25인 영웅") then
					getglobal(rowName.."DungeonText"):SetTextColor(1.0, 0.7, 0.7);
				elseif (info.mode == "25인") then
					getglobal(rowName.."DungeonText"):SetTextColor(1.0, 0.7, 0);
				elseif (info.mode == "10인 영웅") then
					getglobal(rowName.."DungeonText"):SetTextColor(0, 1, 0.7);
				elseif (info.mode == "10인") then
					getglobal(rowName.."DungeonText"):SetTextColor(0, 1, 0);
				--명예 / 귀속 분류 삭제에 따른 주석처리 by 영원이란
				--elseif (info.mode == "명예") then
				--	getglobal(rowName.."DungeonText"):SetTextColor(1, 0, 0);
				elseif (info.mode == "영웅") then
					getglobal(rowName.."DungeonText"):SetTextColor(0.5, 0.5, 0.8);
				--명예 / 귀속 분류 삭제에 따른 주석처리 by 영원이란
				--elseif (info.mode == "귀속") then
				--	getglobal(rowName.."DungeonText"):SetTextColor(1, 0.75, 0.2);
				else
					getglobal(rowName.."DungeonText"):SetTextColor(1,1,1);
				end

				-- Name
				local name = info.name;
				if (info.level) then name = name.." ("..tostring(info.level)..")"; end
				if (info.class) then
					local color = FP_CLASS_COLORS[info.class];
					if (color) then
						getglobal(rowName.."NameText"):SetTextColor(color.r, color.g, color.b);
					end
				else
					getglobal(rowName.."NameText"):SetTextColor(1,1,1);
				end
				getglobal(rowName.."NameText"):SetText(name);

				-- Highlight
				if (info == ShouterSelected) then
					getglobal(rowName):LockHighlight();
				else
					getglobal(rowName):UnlockHighlight();
				end
			end
		else
			getglobal(rowName):Hide();
		end -- end of if

		-- for next
		dataIdx = dataIdx + 1;
		rowIdx = rowIdx + 1;
	end -- end of while
	FP_Debug("|cffff0000■■■■■■FP_Refresh End|r");
end

function FP_Scroll()
	if (not FP_Scroll_Info) then return; end
	FP_Scroll_Info.max = table.getn(FP_Datas);
	FauxScrollFrame_Update(FP_ListFrameScrollFrame, FP_Scroll_Info.max, FP_Scroll_Info.viewLines, FP_Scroll_Info.height);
	FP_Debug("offset = "..tostring(FauxScrollFrame_GetOffset(FP_ListFrameScrollFrame)));
	FP_Refresh();
end

function FP_ListAdjust(adjust)
	local newNumRow;
	local curNumRow = FP_Scroll_Info.viewLines;
	if (not adjust) then
		local curHeight = FP_ListFrame:GetHeight();
		newNumRow = math.floor((curHeight - 40) / FP_Scroll_Info.height);
	elseif (adjust == INC) then
		newNumRow = math.min(MAX_VIEW_LINE, FP_Scroll_Info.viewLines + 1);
	elseif (adjust == DEC) then
		newNumRow = math.max(MIN_VIEW_LINE, FP_Scroll_Info.viewLines - 1);
	elseif (adjust == MAX) then
		newNumRow =MAX_VIEW_LINE;
	elseif (adjust == MIN) then
		newNumRow =MIN_VIEW_LINE;
	end

--	for i=newNumRow + 1, curNumRow, 1 do
--		getglobal("FP_ListFrameRow"..i):Hide();
--	end

	FP_Scroll_Info.viewLines = newNumRow;

	FP_ListResize();
end

local COLUMFRAME = {"DungeonText", "NameText", "MsgText"};

function FP_FontResize()
	for i=1, MAX_VIEW_LINE do
		rowName = "FP_ListFrameRow"..i;
		for j=1, 3 do
			local tempFrame = getglobal(rowName..COLUMFRAME[j]);
			local fontFile, unused, fontFlags = tempFrame:GetFont();
			tempFrame:SetFont(fontFile, FP_Options.fontsize, fontFlags);
		end
	end
end

function FP_SetListColor()
	FP_ListFrame:SetBackdropColor(FP_Options.color.r, FP_Options.color.g, FP_Options.color.b, FP_Options.color.opacity);
end

function FP_UIResize(scale)
	FP_Frame:SetScale(scale);
end

function FP_ListResize()
	local newListHeight = 40 + FP_Scroll_Info.viewLines * FP_Scroll_Info.height;
	--local newScrollHeight = 15 + FP_Scroll_Info.viewLines * FP_Scroll_Info.height;

	FP_ListFrame:SetHeight(newListHeight);
	-- FP_ListFrameScrollFrame:SetHeight(newScrollHeight)
	--FP_ListFrameScrollFrameMiddle:SetHeight(newScrollHeight - 50);

	FP_Scroll();
end

function FP_SortButtonClicked()
	local id = this:GetID();

	FP_Debug("sort "..tostring(id));
	column = Col_Name[id];

	FP_Sort_Info[column] = not FP_Sort_Info[column];
	FP_Sort_Info.current_sort = column;

	FP_Refresh();
	return FP_Sort_Info[column];
end

function FP_ListSort(list, col, ascd)
	if (list ~= nil and col ~= nil) then
		local endIdx = getn(list)
		for i=1, endIdx,1 do
			for j=i+1, endIdx, 1 do
				local pivot = list[i][col];
				local comp = list[j][col];

				if ((ascd and (pivot > comp)) or (not ascd and (pivot < comp))) then
					local temp = list[i];
					list[i] = list[j];
					list[j] = temp;
				end
			end
		end
	end
end

function FP_Party_Find_Class(class, selected)
	local temp = Party_Find_Info.class;
	if (selected) then
		table.insert(temp, class);
	else
		for i=1, table.getn(temp) do
			if (temp[i]==class) then
				table.remove(temp, i);
				break;
			end
		end
	end
end

function FP_Announce()
	FP_Debug("파티모으기 "..tostring(Party_Find_Info.dungeon).."  "..tostring(table.getn(Party_Find_Info.class)));
	local msg = "";

	if (FP_Options.userdefine) then
		msg = FP_FindFrameAdText:GetText();
		FP_UserDefinedAdMsg = msg; -- For save
		if (not msg or string.len(msg) == 0) then
			-- 알림 메세지 by 영원이란
			DEFAULT_CHAT_FRAME:AddMessage("|cffffff00광고글을 작성하셔야 합니다.");
			FP_Debug("|cffffff00광고글을 작성하셔야 합니다.");
			FP_StopAnnounce();
			return;
		end
		else
			if (Party_Find_Info.selected and table.getn(Party_Find_Info.class) > 0) then
				msg = Party_Find_Info.dungeon.." ("..Party_Find_Info.mode.." )";
				msg = msg.." --> ";
				for v,k in pairs(Party_Find_Info.class) do
					msg = msg.." "..k;
				end
				msg = msg.." <-- 오세요";
			else
				-- 알림 메세지 by 영원이란.
				DEFAULT_CHAT_FRAME:AddMessage("|cffffff00던전을 선택하고 클래스가 최소한 1개 이상 선택되어야 합니다.");
				FP_Debug("|cffffff00던전을 선택하고 클래스가 최소한 1개 이상 선택되어야 합니다.");
				FP_StopAnnounce();
			return;
		end
	end

	FP_Debug(msg);
	for k,v in pairs(FP_Options.channel) do
		if (v) then
			local chaNum = GetChannelName(k);
			SendChatMessage(msg, "CHANNEL",  this.language, chaNum);
		end
	end
end

function FP_StopAnnounce()
	-- 파티 모집 시작 알림 메시지 by 영원이란
	DEFAULT_CHAT_FRAME:AddMessage("|cffffff00파티 모으기를 중단합니다.");
	FP_Debug("|cffffff00파티 모으기를 중단합니다.");
	Party_Find_Info.announcing = false;

	FP_FindFrameAnnounce:SetText("광고 시작");
	FP_TitleFrameAnnouncing:SetNormalTexture("Interface\\Icons\\INV_Misc_GroupLooking");
end

function FP_StartAnnounce()
	-- 파티 모집 중단 알림 메세지 by 영원이란
	FP_Debug("|cffffff00파티 모으기를 시작합니다.");
	DEFAULT_CHAT_FRAME:AddMessage("|cffffff00파티 모으기를 시작합니다.");

	announce_timer = GetTime() * 1000;
	Party_Find_Info.announcing = true;

	FP_Debug(tostring(GetTime() * 1000));

	FP_FindFrameAnnounce:SetText("광고 중단");
	FP_TitleFrameAnnouncing:SetNormalTexture("Interface\\Icons\\INV_Misc_GroupNeedMore");

	FP_Announce();
end

function FP_IsAnnoucing()
	return Party_Find_Info.announcing;
end

function FP_IsActivated()
	return FP_Options.activated;
end

function FP_IsActiveBellnWindow()
	return FP_Options["activateBellnWindow"];
end

function FP_IconClicked()
	if (arg1 == "LeftButton") then
		if (IsAltKeyDown()) then
			this:SetMovable(true);
			FP_Options.iconLocked = not FP_Options.iconLocked;
		elseif (IsShiftKeyDown()) then
			FP_Activate(not FP_IsActivated());
		elseif (IsControlKeyDown()) then
			if (FP_IsAnnoucing()) then
				FP_StopAnnounce();
			else
				FP_StartAnnounce();
			end
		else
			if (FP_Frame:IsShown()) then
				FP_Frame:Hide()
			else
				FP_Frame:Show();
			end
		end
	else
		FP_MenuClicked("MENU_OPTION");
	end
end

function FP_MenuClicked(menu, option)
	FP_Debug("Menu "..tostring(menu).." "..tostring(option));
	FP_Debug("click "..tostring(arg1).." / "..tostring(arg2).." //"..tostring(arg3));

	if (menu == "MENU_DUNGEON") then
		UIDropDownMenu_Initialize(FP_DropDownMenu, FP_DropDownMenuFindDungeon_Initialize, "MENU");
		ToggleDropDownMenu(1, nil, FP_DropDownMenu, this, 0, 0);
	elseif (menu == "MENU_FILTERDUNGEON") then
		if (arg1 == "LeftButton") then
			local filtered = FP_Filter_Dungeon_Info.filtered;

			if (filtered or (not filtered and FP_Filter_Dungeon_Info.num < 1)) then
				FP_SortButtonClicked();
				FP_Filter_Dungeon_Info.filtered = false;
				FP_ListFrameFilterDungeonText:SetText("던전: 모두(정렬)");
			else
				FP_Filter_Dungeon_Info.filtered = true;
				FP_ListFrameFilterDungeonText:SetText(FP_GetDungeonFilterDesc());
			end

			FP_Scroll();
		else
			if (arg2) then
				UIDropDownMenu_Initialize(FP_DropDownMenu, FP_DropDownMenuFilterDungeon_Initialize, "MENU");
				ToggleDropDownMenu(1, nil, FP_DropDownMenu, this, 0, 0);
			else
				CloseDropDownMenus();
			end
		end
	elseif (menu=="MENU_CLASS") then
		if (arg1 == "LeftButton") then
			FP_Debug("class filter "..FP_Filter_Class);
			if (FP_Filter_Class == UnitClass("player")) then
				this.value = "모두";
			else
				this.value = UnitClass("player");
			end

			FP_ClassSelected();
		else
			if (arg2) then
				UIDropDownMenu_Initialize(FP_DropDownMenu, FP_DropDownMenuClass_Initialize, "MENU");
			end;
			ToggleDropDownMenu(1, nil, FP_DropDownMenu, this, FP_ListFrameFilterClass:GetWidth()/2, 0);
		end
	elseif (menu=="MENU_OPTION") then
		FP_GetChannels();
		UIDropDownMenu_Initialize(FP_DropDownMenu, FP_DropDownMenuOption_Initialize, "MENU");
		ToggleDropDownMenu(1, nil, FP_DropDownMenu, this, 0, 0);
	elseif (menu == "MENU_APPLY") then
		if (ShouterSelected) then
			local playerClass =UnitClass("player");
			local msg="";
			if (FP_Options.userdefineWh) then
				msg = FP_FindFrameWhText:GetText();
				FP_UserDefinedWhMsg = msg; -- For save
			else
				local myTalent = FP_GetMyTalent();
				msg = myTalent.." "..playerClass.." 손 !!";
				--msg = playerClass.."["..myTalent.."]".." 손 !!";
			end
			FP_Debug(msg);
			SendChatMessage(msg, "WHISPER", this.language, ShouterSelected.name);
		end
	elseif (menu == "MENU_WHO") then
		if (ShouterSelected) then
--			local ppp=0
--			if string.find(ShouterSelected.name, "[a-z]+") then ppp=1 end
--			if ppp==1 then SendWho(ShouterSelected.name) else SendWho(ShouterSelected.name.."....") end
			SendWho(ShouterSelected.name)
		end
	elseif (menu == "MENU_EXCEPTION") then
		if (ShouterSelected) then
			if ( FP_Exceptions ) then savePlace = #FP_Exceptions+1; end
			FP_Exceptions[savePlace] = ShouterSelected.name

			for i=1,#FP_Exceptions,1 do
				FP_Debug(FP_Exceptions[i])	
			end
		end
	elseif (menu == "MENU_EXCEPTION_DELETE") then
		FP_Exceptions = {};	
	elseif (menu == "MENU_ANNOUNCE") then
		if (Party_Find_Info.announcing) then
			FP_StopAnnounce();
		else
			FP_StartAnnounce();
		end
	elseif (menu == "MENU_ACTIVATE_BELLNWINDOW") then
		FP_ActiveBellnWindow(FP_Options.activateBellnWindow);
	elseif (menu == "MENU_ACTIVATION") then
		-- FP_Debug("Activation changed");
		FP_Activate(not FP_Options.activated);
	elseif (menu == "MENU_INC") then
		FP_ListAdjust(INC);
	elseif (menu == "MENU_DEC") then
		FP_ListAdjust(DEC);
	elseif (menu == "MENU_MAX") then
		FP_ListAdjust(MAX);
	elseif (menu == "MENU_MIN") then
		FP_ListAdjust(MIN);
	elseif (menu == "MENU_INFO") then
		for i=1, table.getn(FP_HELPS) do
			-- 정보 버튼 활성화 by 영원이란
			DEFAULT_CHAT_FRAME:AddMessage(FP_HELPS[i]);
			FP_Debug(FP_HELPS[i]);
		end
	elseif (menu == "SEL_SHOUT") then
		local index = this:GetID();
		local data = FP_Datas[index];

		if (IsAltKeyDown()) then
			ShouterSelected = data;
			FP_MenuClicked("MENU_APPLY");
		elseif (IsShiftKeyDown()) then
			ShouterSelected = data;
			FP_MenuClicked("MENU_WHO");
		elseif (IsControlKeyDown()) then
			ShouterSelected = data;
			FP_MenuClicked("MENU_EXCEPTION");
		else
			if (ShouterSelected == data) then
				ShouterSelected = nil;
			else
				ShouterSelected = data;
			end
		end

		FP_Refresh();
	elseif (menu=="SEL_ETC") then
		FP_Options.userdefine = option;
	elseif (menu=="SEL_ETC2") then
		FP_Options.userdefineWh = option;
		--Party_Find_Info.userdefineWh = option;
		elseif (menu=="SEL_WARRIOR") then FP_Party_Find_Class( "전사", option);
		elseif (menu=="SEL_PRIEST") then FP_Party_Find_Class("사제", option);
		elseif (menu=="SEL_PALADIN") then FP_Party_Find_Class("성기사", option);
		elseif (menu=="SEL_MAGE") then FP_Party_Find_Class("마법사", option);
		elseif (menu=="SEL_WARROCK") then FP_Party_Find_Class("흑마법사", option);
		elseif (menu=="SEL_HUNTER") then FP_Party_Find_Class("사냥꾼", option);
		elseif (menu=="SEL_DRUID") then FP_Party_Find_Class("드루이드", option);
		elseif (menu=="SEL_ROGUE") then FP_Party_Find_Class("도적", option);
		elseif (menu=="SEL_SHAMAN") then FP_Party_Find_Class("주술사", option);
		elseif (menu=="SEL_DEATHKNIGHT") then FP_Party_Find_Class("죽음의 기사", option);
	end
end

function FP_LoadDefaultDungeonList()
	-- 알림 메세지 by 영원이란
	DEFAULT_CHAT_FRAME:AddMessage("|cffffff00던전 리스트 기본값을 불러옵니다.");
	FP_Debug("|cffffff00 던전 리스트 기본값을 불러옵니다");
	FP_DUNGEON_LIST = {};
	sort(FP_DEFAULT_DUNGEON_LIST);
	for z, dTbl in pairs(FP_DEFAULT_DUNGEON_LIST) do
		FP_Debug("zone : "..z)
		FP_DUNGEON_LIST[z] = {};

		sort(dTbl);
		for d,aTbl in pairs(dTbl) do
			FP_Debug("dungeon : "..d)
			FP_DUNGEON_LIST[z][d] = {};

			sort(aTbl);
			for i, alias in ipairs(aTbl) do
				FP_DUNGEON_LIST[z][d][i] = alias;
			end
		end
	end
	--FP_OPTION_LIST["던전 편집"] = FP_DUNGEON_LIST;
end

function FP_AddDungeonList()
	FP_Debug("FP_AddDungeonList start.");
	local value = UIDROPDOWNMENU_MENU_VALUE;

	-- trimming text
	local item = this:GetText();
	local useless, useless, str = string.find(item, "(%S+.*)");
	if (str) then
		useless, useless, str = string.find(str, "(.*%S+)");
	else
		return;
	end

	item = str;

	this:SetText(""); -- edit box
	info = {};
	info.notCheckable = true;
	info.hasArrow = true;
	info.value = {
		["level"] = value.level,
		["Zone"] = item,
	}

	if (value.level == 2) then
		FP_DUNGEON_LIST[item] = {};

		info.text = item;
		info.value.Zone = item;
		info.value.subarray = FP_DUNGEON_LIST[item];
	elseif (value.level == 3) then
		FP_DUNGEON_LIST[value.Zone][item] = {item};

		info.text = item;
		info.value.Zone = value.Zone;
		info.value.Dungeon = item;
		info.value.subarray = FP_DUNGEON_LIST[value.Zone][item];
	elseif (value.level == 4) then
		table.insert(FP_DUNGEON_LIST[value.Zone][value.Dungeon], item);

		info.text = item;
		info.value.Zone = value.Zone;
		info.value.Dungeon = value.Dungeon;
		info.value.Alias = item;
		info.value.index = #FP_DUNGEON_LIST[value.Zone][value.Dungeon];
	end

	UIDropDownMenu_AddButton(info, value.level);
	--오류 수정을 위한 주석 처리 by 영원이란
	--FP_Debug("zone-dungeon-alias-index"..info.value.Zone.."-"..info.value.Dungeon.."-"..info.value.Alias.."-"..info.value.index);
	--UIDropDownMenu_Refresh(self, value, value.level);
end

function FP_RemoveDungeonList()
	value = this.value;

	if (value.level == 3) then
		if (next(FP_DUNGEON_LIST[value.Zone])) then
			-- 알림 메세지 by 영원이란
			DEFAULT_CHAT_FRAME:AddMessage("|cffffff00던전 항목이 하나도 없을 때에만 삭제가 가능합니다.");
			FP_Debug("|cffffff00던전 항목들이 하나도 없을 때에만 삭제가 가능합니다.");
		else
			FP_DUNGEON_LIST[value.Zone] = nil;

--			HideDropDownMenu(value.level);
			for i=1,UIDROPDOWNMENU_MAXBUTTONS do
				local button = getglobal("DropDownList"..(value.level-1).."Button"..i);
				if (button and button.value and button.value.Zone == value.Zone) then
					button:Hide();
					break;
				end
			end
		end
	elseif (value.level == 4) then
		-- 오류 방지를 위해 FP_RAID_ORDER에 있는 던전은 삭제가 불가능 하게 한다 by 영원이란
		local delete_ok = true;
		if (value.Zone == "공격대") then
			for k, v in pairs(FP_RAID_ORDER) do
				if (v == value.Dungeon) then
					delete_ok = false;
					break;
				end
			end
		end
		if (delete_ok == false) then
			DEFAULT_CHAT_FRAME:AddMessage("|cffffff00이 공격대 던전은 삭제하실 수 없습니다.");
			FP_Debug("|cffffff00이 공격대 던전은 삭제하실 수 없습니다.");
		else
		-- 수정 끝
			FP_DUNGEON_LIST[value.Zone][value.Dungeon] = nil;

--			HideDropDownMenu(value.level);
			for i=1,UIDROPDOWNMENU_MAXBUTTONS do
				local button= getglobal("DropDownList"..(value.level-1).."Button"..i);
				if (button and button.value and button.value.Dungeon == value.Dungeon) then
					button:Hide();
					break;
				end
			end
		end
	elseif (value.level == 5) then
		local array = FP_DUNGEON_LIST[value.Zone][value.Dungeon];

		for i=1, #FP_DUNGEON_LIST[value.Zone][value.Dungeon] do
			if (FP_DUNGEON_LIST[value.Zone][value.Dungeon][i] == value.Alias) then
				table.remove(FP_DUNGEON_LIST[value.Zone][value.Dungeon], i);
				break;
			end
		end
--		HideDropDownMenu(value.level);
		for i=1,UIDROPDOWNMENU_MAXBUTTONS do
			local button= getglobal("DropDownList"..(value.level-1).."Button"..i);
			if (button and button.value and  button.value.Alias == value.Alias) then
				button:Hide();
				break;
			end
		end
	end
end

function FP_FindDungeonSelected()
	if (this.value) then
		Party_Find_Info.dungeon = this.value.Dungeon;
		Party_Find_Info.selected = true;
		if (this.value.Mode) then
			Party_Find_Info.mode = this.value.Mode;
		else
			Party_Find_Info.mode = "일반";
		end

		ToggleDropDownMenu(1, nil, FP_DropDownMenu, FP_FindFrameDungeon, 0, 0);
	end

	FP_FindFrameDungeonNameText:SetText(Party_Find_Info.dungeon);

	-- 색처리 세분화 / 수정
	-- 25인 하드 / 10인 하드 구분 추가 by 영원이란
	if (Party_Find_Info.mode == "25인 영웅") then
		FP_FindFrameDungeonNameText:SetTextColor(1.0, 0.7, 0.7);
	elseif (Party_Find_Info.mode == "25인") then
		FP_FindFrameDungeonNameText:SetTextColor(1.0, 0.7, 0);
	elseif (Party_Find_Info.mode == "10인 영웅") then
		FP_FindFrameDungeonNameText:SetTextColor(0, 1, 0.7);
	elseif (Party_Find_Info.mode == "10인") then
		FP_FindFrameDungeonNameText:SetTextColor(0, 1, 0);
	elseif (Party_Find_Info.mode == "영웅") then
		FP_FindFrameDungeonNameText:SetTextColor(0.5, 0.5, 0.8);
	else
		FP_FindFrameDungeonNameText:SetTextColor(1,1,1);
	end

--	if (Party_Find_Info.mode =="영웅") then
--		FP_FindFrameDungeonNameText:SetTextColor(1.0, 0.82, 0);
--	else
--		FP_FindFrameDungeonNameText:SetTextColor(1,1,1);
--	end
end

function FP_FilterDungeonSelected(self)
	if (self.value) then
		if (self.value == "resetall") then
			FP_Filter_Dungeon_Info.dungeons = {};
			FP_Filter_Dungeon_Info.zones = {};
			FP_Filter_Dungeon_Info.filtered = false;
			FP_Filter_Dungeon_Info.num = 0;
		else
			FP_Filter_Dungeon_Info.filtered = true;

			local zone = self.value.Zone;
			local dungeon = self.value.Dungeon;
			local mode = self.value.Mode;
			
			-- 필터링 체크 재작성 및 FP_Filter_Dungeon_Info 구조 변경 by 영원이란
			-- mode 값이 있는 경우 : 난이도 전체 선택(1레벨), 던전별 난이도 세부 선택(3레벨)
			if (mode) then
				-- 1, 3 레벨 구분 : zone 값이 있으면 던전 난이도를 세부 선택한 3레벨이다.
				if (zone) then
					-- 필터 DB 에서 비교, 이미 던전이 필터에 있으므로 체크 난이도 제거 또는 추가
					if (dungeon and FP_Filter_Dungeon_Info.dungeons[dungeon]) then
						-- 필터 DB에서 체크 난이도가 존재하는지 확인. 확인 될 경우 제거
						if (FP_Filter_Dungeon_Info.dungeons[dungeon][mode] == true) then
							FP_Filter_Dungeon_Info.dungeons[dungeon][mode] = false;
							-- 필터 DB에서 체크 난이도를 제거하고 나서 모든 난이도가 체크 해제 될 경우 해당 던전을 DB에서 완전히 제거
							local cnt = 0;
							for k, v in pairs(FP_Filter_Dungeon_Info.dungeons[dungeon]) do
								if (v == true) then
									cnt = cnt + 1;
								end
							end
							if (cnt == 0) then
								FP_Filter_Dungeon_Info.dungeons[dungeon] = nil;
								local chk = 0;
								for k, v in pairs(FP_DUNGEON_LIST[zone]) do
									for v, j in pairs(FP_Filter_Dungeon_Info.dungeons) do
										if (v == k) then
											chk = chk + 1;
										end
									end
								end
								if (chk == 0) then
									FP_Filter_Dungeon_Info.zones[zone] = nil;
								end
								FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num - 1;
								FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
							end
						-- 필터 DB에 체크 난이도를 추가
						else
							FP_Filter_Dungeon_Info.dungeons[dungeon][mode] = true
						end
					-- 필터 DB에 없으므로 체크 던전 및 난이도를 필터 DB에 추가
					else
						if (FP_Filter_Dungeon_Info.dungeons[dungeon] == nil) then
							FP_Filter_Dungeon_Info.dungeons[dungeon] = {["25인 영웅"] = false, ["25인"] = false, ["10인 영웅"] = false, ["10인"] = false, ["영웅"] = false, ["일반"] = false, ["loc"] = false};
						end
						FP_Filter_Dungeon_Info.dungeons[dungeon][mode] = true;
						FP_Filter_Dungeon_Info.dungeons[dungeon]["loc"] = zone;
						FP_Filter_Dungeon_Info.zones[zone] = true;
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
					end
				-- 1레벨 처리 부분 : 난이도 전체 선택
				else
					-- 난이도 전체 선택을 이미 했을 경우 취소. 토글형임 // zones 사용
					-- 필터 DB를 검색해서 해당 난이도를 전부 false 로 바꾼다
					if (FP_Filter_Dungeon_Info.zones[mode] == true) then
						for k, v in pairs(FP_Filter_Dungeon_Info.dungeons) do
							FP_Filter_Dungeon_Info.dungeons[k][mode] = false;
							-- 필터 DB 에서 해당 난이도를 제거하고 나서 모든 난이도가 체크 해제 될 경우 해당 던전을 DB에서 완전히 제거
							local cnt = 0;
							local temp = FP_Filter_Dungeon_Info.dungeons[k]["loc"];
							for v, j in pairs(FP_Filter_Dungeon_Info.dungeons[k]) do
								if (j == true) then
									cnt = cnt + 1;
								end
							end
							if (cnt == 0) then
								FP_Filter_Dungeon_Info.dungeons[k] = nil;
								local chk = 0;
								for t, n in pairs(FP_DUNGEON_LIST[temp]) do
									for n, p in pairs(FP_Filter_Dungeon_Info.dungeons) do
										if (n == t) then
											chk = chk + 1;
										end
									end
								end
								if (chk == 0) then
									FP_Filter_Dungeon_Info.zones[temp] = nil;
								end
							end
						end
						-- 필터된 갯수 재 계산
						FP_Filter_Dungeon_Info.num = 0;
						for a, b in pairs(FP_Filter_Dungeon_Info.dungeons) do
							FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
						end
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
						FP_Filter_Dungeon_Info.zones[mode] = nil;
					-- 선택된 난이도를 필터 DB에 추가 던전 목록을 전부 검색하여 필터 DB에 추가한다. (난이도는 아웃랜드, 노스렌드, 공격대 던전에만 해당)
					else
						for k, v in pairs(FP_DUNGEON_LIST) do
							if (k == "아웃랜드" or k == "노스렌드" or  k == "공격대") then
								for v, j in pairs(FP_DUNGEON_LIST[k]) do
									if (FP_Filter_Dungeon_Info.dungeons[v] == nil) then
										FP_Filter_Dungeon_Info.dungeons[v] = {["25인 영웅"] = false, ["25인"] = false, ["10인 영웅"] = false, ["10인"] = false, ["영웅"] = false, ["일반"] = false, ["loc"] = false};
									end
									FP_Filter_Dungeon_Info.dungeons[v][mode] = true;
									FP_Filter_Dungeon_Info.dungeons[v]["loc"] = k;
									FP_Filter_Dungeon_Info.zones[k] = true;
								end
							end
						end
						-- 필터된 갯수 재 계산
						FP_Filter_Dungeon_Info.num = 0;
						for a, b in pairs(FP_Filter_Dungeon_Info.dungeons) do
							FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
						end
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
						FP_Filter_Dungeon_Info.zones[mode] = true;
					end
				end
			-- mode 값이 없는 경우 : 지역 전체 선택(1레벨), 던전 전체 선택(2레벨)
			else
				-- 1, 2레벨 구분 : dungeon 값이 있으면 던전을 전체 선택한 2레벨이다.
				if (dungeon) then
					-- 이미 DB에 있는 던전인가? 그렇구나. 그럼 제거 하자.
					if (FP_Filter_Dungeon_Info.dungeons[dungeon]) then
						FP_Filter_Dungeon_Info.dungeons[dungeon] = nil;
						local chk = 0;
						for k, v in pairs(FP_DUNGEON_LIST[zone]) do
							for v, j in pairs(FP_Filter_Dungeon_Info.dungeons) do
								if (v == k) then
									chk = chk + 1;
								end
							end
						end
						if (chk == 0) then
							FP_Filter_Dungeon_Info.zones[zone] = nil;
						end
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num - 1;
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
					-- 아니네~ 그럼 추가하자.
					else
						FP_Filter_Dungeon_Info.dungeons[dungeon] = {["25인 영웅"] = true, ["25인"] = true, ["10인 영웅"] = true, ["10인"] = true, ["영웅"] = true, ["일반"] = true, ["loc"] = zone};
						FP_Filter_Dungeon_Info.zones[zone] = true;
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
					end
				-- 1레벨 처리 부분 : 지역 전체 선택
				else
					-- 세부 항목이 하나라도 선택되어 있을 경우 전체 삭제. zones 이용
					if (FP_Filter_Dungeon_Info.zones[zone] == true) then
						for k,v in pairs(FP_DUNGEON_LIST[zone]) do
							FP_Filter_Dungeon_Info.dungeons[k] = nil;
						end
						-- 필터된 갯수 재 계산
						FP_Filter_Dungeon_Info.num = 0;
						for a, b in pairs(FP_Filter_Dungeon_Info.dungeons) do
							FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
						end
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
						FP_Filter_Dungeon_Info.zones[zone] = nil;
					-- 없으면 지역 아래 던전 전체 DB에 추가
					else
						for k,v in pairs(FP_DUNGEON_LIST[zone]) do
							FP_Filter_Dungeon_Info.dungeons[k] = {["25인 영웅"] = true, ["25인"] = true, ["10인 영웅"] = true, ["10인"] = true, ["영웅"] = true, ["일반"] = true, ["loc"] = zone};
						end
						-- 필터된 갯수 재 계산
						FP_Filter_Dungeon_Info.num = 0;
						for a, b in pairs(FP_Filter_Dungeon_Info.dungeons) do
							FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
						end
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
						FP_Filter_Dungeon_Info.zones[zone] = true;
					end
				end
			end

			-- For GUI (동기화를 위해 코드 새로 작성)
			ToggleDropDownMenu(self.value.level + 1, self.value, FP_DropDownMenu, self, 0, 0, nil, self);
			ToggleDropDownMenu(self.value.level + 1, self.value, FP_DropDownMenu, self, 0, 0, nil, self);

			if (self.value.level == 1) then
				local menu_cnt = 0;
				for c, n in pairs(FP_DUNGEON_LIST) do
					menu_cnt = menu_cnt + 1;
				end
				for i=1, menu_cnt + 9 do
					local button = getglobal("DropDownList1Button"..i);
					local text = button.value.Zone or button.value.Mode;
					local btn1_chk = false;
					for k, v in pairs(FP_Filter_Dungeon_Info.zones) do
						if (k == text) then
							btn1_chk = true;
						end
					end
					if (btn1_chk == true) then
						button.checked = true;
						getglobal("DropDownList1Button"..i.."Check"):Show();
					else
						button.checked = false;
						getglobal("DropDownList1Button"..i.."Check"):Hide();
					end
				end
			end

			if (self.value.level == 2) then
				local btn2_chk = 0;
				for i=1, UIDROPDOWNMENU_MAXBUTTONS do
					local button = getglobal("DropDownList2Button"..i);
					if (button.checked) then
						btn2_chk = btn2_chk + 1;
					end
				end
				local point, upLevelButton = self:GetParent():GetPoint();
				if (upLevelButton.checked) then
					if (btn2_chk == 0) then
						upLevelButton.checked = nil;
						getglobal(upLevelButton:GetName().."Check"):Hide();
					end
				else
					if (btn2_chk ~= 0) then
						upLevelButton.checked = true;
						getglobal(upLevelButton:GetName().."Check"):Show();
					end
				end
			end

			if (self.value.level == 3) then
				local btn2_chk = 0;
				local btn3_chk = 0;
				for i=1, UIDROPDOWNMENU_MAXBUTTONS do
					local button = getglobal("DropDownList3Button"..i);
					if (button.checked) then
						btn3_chk = btn3_chk + 1;
					end
				end
				local point, upLevelButton = self:GetParent():GetPoint();
				local point2, upLevelButton2 = upLevelButton:GetParent():GetPoint();
				if (upLevelButton.checked) then
					if (btn3_chk == 0) then
						upLevelButton.checked = nil;
						getglobal(upLevelButton:GetName().."Check"):Hide();
						for j=1, UIDROPDOWNMENU_MAXBUTTONS do
							local button2 = getglobal("DropDownList2Button"..j);
							if (button2.checked) then
								btn2_chk = btn2_chk + 1;
							end
						end
						if (btn2_chk == 0) then
							upLevelButton2.checked = nil;
							getglobal(upLevelButton2:GetName().."Check"):Hide();
						end
					end
				else
					if (btn3_chk ~= 0) then
						upLevelButton.checked = true;
						upLevelButton2.checked = true;
						getglobal(upLevelButton:GetName().."Check"):Show();
						getglobal(upLevelButton2:GetName().."Check"):Show();
					end
				end
			end

--[[ 오리지널 코드 삭제 by 영원이란
			if (not (dungeon == "ALL")) then -- dungeon이 ALL 인 경우는 난이도를 선택했을 경우
				-- 개별 던전이 선택되면 난이도 선택은 취소
				FP_Filter_Dungeon_Info.dungeons["ALL"] = nil;
			end

			if (not mode) then
				if (dungeon and FP_Filter_Dungeon_Info.dungeons[dungeon]) then
					mode = FP_Filter_Dungeon_Info.dungeons[dungeon].mode;
				else
					mode = "전체";
				end
			end

			-- for Control
			-- 변수값 조정
			if (dungeon) then
				if (FP_Filter_Dungeon_Info.dungeons[dungeon]) then
					if (FP_Filter_Dungeon_Info.dungeons[dungeon].mode == mode) then
						if (zone) then  -- 난이도 모드 선택시에는 zone 정보가 nil
							FP_Filter_Dungeon_Info.zones[zone] = nil;
						end
						FP_Filter_Dungeon_Info.dungeons[dungeon] = nil;
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num - 1;
						FP_Filter_Dungeon_Info.filtered = not (FP_Filter_Dungeon_Info.num == 0);
					else
-						if (FP_Filter_Dungeon_Info.dungeons[dungeon].mode == "전체") then
							if (mode == "영웅") then
								FP_Filter_Dungeon_Info.dungeons[dungeon].mode = "일반";
							else
								FP_Filter_Dungeon_Info.dungeons[dungeon].mode = "영웅";
							end
							FP_Filter_Dungeon_Info.dungeons[dungeon].mode = "전체";
							FP_RegistLFG(dungeon, "일반");	-- Looking For Group 자동 추가 메소드(예정)
							FP_RegistLFG(dungeon, "영웅");	-- Looking For Group 자동 추가 메소드(예정)
						else
							FP_Filter_Dungeon_Info.dungeons[dungeon].mode = mode;
							FP_RegistLFG(dungeon, mode);	-- Looking For Group 자동 추가 메소드(예정)
						end
					end
				else
					FP_Filter_Dungeon_Info.dungeons[dungeon] = {["mode"] = mode, ["zone"]= zone};
					FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
				end
			-- zone 영역 전체 선택
			else
				if self.checked then
					FP_Filter_Dungeon_Info.zones[zone] = true;
				else
					FP_Filter_Dungeon_Info.zones[zone] = nil;
				end

				for k,v in pairs(FP_DUNGEON_LIST[zone]) do
					if self.checked then
						FP_Filter_Dungeon_Info.dungeons[k] = {["mode"] = mode, ["zone"] = zone};
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num + 1;
					else
						FP_Filter_Dungeon_Info.dungeons[k] = nil;
						FP_Filter_Dungeon_Info.num = FP_Filter_Dungeon_Info.num - 1;
					end
				end
				-- ToggleDropDownMenu(self.value.level + 1, self.value, self);
			end

			-- For GUI
			ToggleDropDownMenu(self.value.level + 1, self.value, FP_DropDownMenu, self, 0, 0, nil, self);

			if (FP_Filter_Dungeon_Info.dungeons["ALL"]) then
				local button1 = getglobal("DropDownList1Button2");
				local button2 = getglobal("DropDownList1Button3");
				if (self == button1) then
					button2.checked = nil;
					getglobal("DropDownList1Button3Check"):Hide();
				elseif (self == button2) then
					button1.checked = nil;
					getglobal("DropDownList1Button2Check"):Hide();
				end
			else
				--getglobal("DropDownList1Button2").checked = nil;
				--getglobal("DropDownList1Button3").checked = nil;
				getglobal("DropDownList1Button3Check"):Hide();
				getglobal("DropDownList1Button2Check"):Hide();
			end

			if (self.value.level == 2) then
				local point, upLevelButton = self:GetParent():GetPoint();
				if (upLevelButton.checked) then
					upLevelButton.checked = nil;
					getglobal(upLevelButton:GetName().."Check"):Hide();
				end
			end

			if (self.value.level == 3) then
				local point, upLevelButton = self:GetParent():GetPoint();
				upLevelButton.checked = FP_Filter_Dungeon_Info.dungeons[dungeon];
				if (upLevelButton.checked) then
					getglobal(upLevelButton:GetName().."Check"):Show();
				else
					getglobal(upLevelButton:GetName().."Check"):Hide();
				end

				for i=1,2 do
					local button = getglobal("DropDownList3Button"..i);
					if (self ~= button) then
						if (FP_Filter_Dungeon_Info.dungeons[dungeon] and FP_Filter_Dungeon_Info.dungeons[dungeon].mode ~= button.value.Mode) then
							getglobal("DropDownList3Button"..i.."Check"):Hide();
							button.checked = ni;
						end
					end
				end
			end
]]--

		end -- end of if (self.value=="resetall")...
	end -- end of if (self.value) then...

	FP_ListFrameFilterDungeonText:SetText("던전: "..FP_GetDungeonFilterDesc());
end

function FP_GetDungeonFilterDesc()
	local desc = "모두(정렬)";

-- 필터 문자열 얻어오는 함수 변경 by 영원이란
	if (FP_Filter_Dungeon_Info.filtered) then
		if (FP_Filter_Dungeon_Info.num > 15) then
			desc = "15곳 초과";
		else
			desc = "";
			count = 0;
			for d, m in pairs(FP_Filter_Dungeon_Info.dungeons) do
				if (count > 0) then desc = desc..","; end
				desc = desc..d;
				FP_Debug("desc = "..desc);
				if (m and (m.loc == "아웃랜드" or m.loc == "노스렌드" or m.loc == "공격대")) then
					desc2 = "(";
					count2 = 0;
					if (m["일반"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."일반";
						count2 = count2 + 1;
					end
					if (m["영웅"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."영웅";
						count2 = count2 + 1;
					end
					if (m["10인"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."10인";
						count2 = count2 + 1;
					end
					if (m["25인"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."25인";
						count2 = count2 + 1;
					end
					if (m["10인 영웅"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."10인 영웅";
						count2 = count2 + 1;
					end
					if (m["25인 영웅"] == true) then
						if (count2 > 0) then desc2 = desc2..","; end
						desc2 = desc2.."25인 영웅";
						count2 = count2 + 1;
					end
					desc2 = desc2..")";
					if (count2 == 6) then
						desc2 = "(전체)";
					end
					desc = desc..desc2;
					FP_Debug("desc = "..desc);
				end
				count = count + 1
			end
			if (count == 0) then
				desc = "선택 없음";
			end
			if (count > 1) then
				desc = count.."곳:"..desc;
			end
		end
	end

--[[ 오리지널 코드 삭제 - DB 저장값 수정에 따른 수정 by 영원이란
		desc_z = "";
		local count_z = 0;
		for z, v in pairs(FP_Filter_Dungeon_Info.zones) do
			if 
			if (count_z > 0) then desc_z = desc_z..","; end
			desc_z = desc_z..z;
			count_z = count_z + 1;
		end
		desc_d = "";
		count_d = 0;
		for d, m in pairs(FP_Filter_Dungeon_Info.dungeons) do
			if (not FP_Filter_Dungeon_Info.zones[m.zone]) then
				if (count_d > 0) then desc_d = desc_d..","; end
				desc_d = desc_d..d;
				FP_Debug("desc = "..desc);
				if (m and (m.zone == "아웃랜드" or m.zone == "노스렌드" or m.zone == "공격대")) then
					desc_d = desc_d.."("..m.mode..")";
					FP_Debug("desc = "..desc);
				end
				count_d = count_d + 1;
			end
			FP_Debug("desc = "..desc);
			if (count_d > 1) then
				desc_d = count_d.."곳:"..desc_d;
			end
			FP_Debug("desc = "..desc);
			if (count_z > 0) then
				if (count_d > 0 ) then
					desc = desc_z..","..desc_d;
				else
					desc = desc_z;
				end
			elseif (count_d > 0) then
				desc = desc_d;
			else
				desc = "선택 없음";
			end
		end
]]--

	return desc;
end

function FP_GetClassFilterInfo()
	return FP_Filter_Class;
end

function FP_ClassSelected()
	FP_Debug("class sected "..this.value);
	if (this.value) then
		FP_Filter_Class = this.value;
		FP_Debug("class filter = "..FP_Filter_Class);
		FP_Scroll();
	end

	FP_ListFrameFilterClassText:SetText("직업 골라내기 : "..FP_Filter_Class);
end

function FP_ColorSelected(previousValues)
	if (not previousValues) then
		FP_Options.color.r, FP_Options.color.g, FP_Options.color.b = ColorPickerFrame:GetColorRGB();
		FP_Options.color.opacity = OpacitySliderFrame:GetValue();
	else
		FP_Options.color=previousValues;
	end

	FP_Debug("color r="..FP_Options.color.r.." g="..FP_Options.color.g.." b="..FP_Options.color.b.." a="..FP_Options.color.opacity);
	FP_SetListColor();
end

function FP_OptionSelected()
	if (this.value) then
		local option = this.value.Option;
		local value = this.value.Value;

		local opName = FP_OPTION_NAME[option];
		local opType = type(FP_Options[opName]);

		if (opType == "number") then
			FP_Options[opName] = tonumber(value);
		elseif (opType == "string") then
			FP_Options[opName] = tostring(value);
		elseif (opType == "nil" or opType == "boolean") then
			FP_Options[opName] = not FP_Options[opName];
		elseif (opType == "table") then
			FP_Options[opName][value] = not this.checked;
		end

		if (opName == "scale") then
			FP_UIResize(FP_Options.scale);
		elseif (opName == "fontsize") then
			FP_FontResize()
		elseif (opName == "reset") then
			FP_Options[opName] = nil;

			if (value == "창 위치") then
				FP_ListFrame:SetPoint("TOPLEFT", UIParent,"TOP", -(FP_ListFrame:GetWidth()/2), -50);
			elseif (value  == "창 크기") then
				FP_Options.scale = 1;
				FP_UIResize(FP_Options.scale);
				FP_ListAdjust(MAX);
				FP_ListFrame:SetWidth(650);
			end
		end

		if(opName=="esc")then
			if( FP_Options[FP_OPTION_NAME["ESC로 창 닫기"]] ) then
				tinsert(UISpecialFrames, "FP_Frame");

			else
				for i=1, #UISpecialFrames do
					local v = UISpecialFrames[i];
					if (v == "FP_Frame") then
						table.remove(UISpecialFrames, k)
					end
				end
			end
		end

	ToggleDropDownMenu(1, nil, FP_DropDownMenu, FP_TitleFrameOption, 0, 0);
	end
end

function FP_GetMyTalent()
	local myTalent;

	local talentTabName, _, talentPoints;
	local currentTalentPoints = 0;
	for i=1,3,1 do
		talentTabName, _, talentPoints = GetTalentTabInfo(i);
		if currentTalentPoints < talentPoints then
			currentTalentPoints = talentPoints;
			myTalent = talentTabName;
		end
	end

	FP_Debug(tostring(myTalent));

	return myTalent;
end

local function DropDownMenuFilterDungeonCheck(level, key, upLevelKey)
	if (level == 2) then
		return FP_Filter_Dungeon_Info.dungeons[key];
	elseif (level == 3) then
		--return (FP_Filter_Dungeon_Info.dungeons[upLevelKey] and (FP_Filter_Dungeon_Info.dungeons[upLevelKey].mode == "전체" or key == FP_Filter_Dungeon_Info.dungeons[upLevelKey].mode));
		if (FP_Filter_Dungeon_Info.dungeons[upLevelKey]) then
			return FP_Filter_Dungeon_Info.dungeons[upLevelKey][key];
		else
			return false;
		end
	end
	return false;
end

function FP_DropDownMenuFilterDungeon_Initialize(frame, level)
	level = level or 1;
	local info = {};
	info.func = FP_FilterDungeonSelected;
	info.keepShownOnClick = true;

	if (level == 1) then
		info.text = "난이도별 선택";
		info.notCheckable = true;
		info.isTitle = true;
		UIDropDownMenu_AddButton(info, level);

		info.disabled = false;
		info.notCheckable = false;
		info.isTitle = false;
		--목록 던전 순서를 맞추기 위해 배열을 하나 더 만듬 by 영원이란
		--for key, subarray in pairs(FP_DUNGEON_MODE) do
		for key, subarray in pairs(FP_DUNGEON_MODE2) do
			--info.text = key.." 던전 모두";
			info.text = subarray.." 던전 모두";
			--info.checked = (FP_Filter_Dungeon_Info.dungeons["ALL"] and FP_Filter_Dungeon_Info.dungeons["ALL"].mode == key);
			--info.checked = FP_Filter_Dungeon_Info.zones[key];
			info.checked = FP_Filter_Dungeon_Info.zones[subarray];
			info.value = {
				["Dungeon"] = "ALL",
				--["Mode"] = key,
				["Mode"] = subarray,
				["level"] = level;
			};
			UIDropDownMenu_AddButton(info, level);
		end

		-- 한줄 비움
		info.checked = false;
		info.text = "";
		info.disabled = true;
		info.value = {["Zone"] = no};
		UIDropDownMenu_AddButton(info, level);

		info.text = "인던별 선택";
		info.notCheckable = true;
		info.isTitle = true;
		info.value = {["Zone"] = no};
		UIDropDownMenu_AddButton(info, level);
		info.disabled = false;
		info.isTitle = false;
		info.notCheckable = false;
		info.hasArrow = true; -- creates submenu
		for key, subarray in pairs(FP_DUNGEON_LIST) do
			info.text = key;
			info.checked = FP_Filter_Dungeon_Info.zones[key];
			info.value = {
				["Zone"] = key,
				["level"] = level,
			};
			UIDropDownMenu_AddButton(info, level);
		end -- for key, subarray
	else
		FP_DropDownMenuDungeon_Initialize(
			self,
			level,
			info,
			FP_FilterDungeonSelected,
			DropDownMenuFilterDungeonCheck
		);
	end

	if (level == 1) then
		-- 한줄 비움
		info.text = "";
		info.disabled = true;
		info.checked = false;
		info.hasArrow = false;
		UIDropDownMenu_AddButton(info, level);

		info.text = "* 모두 초기화 *";
		info.value = "resetall";
		info.func = FP_FilterDungeonSelected;
		info.notCheckable = false;
		info.disabled = false;
		info.keepShownOnClick = false;
		info.textR = 0.95;
		info.textG = 0.30;
		info.textB = 0.30;
		UIDropDownMenu_AddButton(info, level);
	end
end

local function DropDownMenuFindDungeonCheck(level, key, upLevelKey)
	if (level == 2) then
		return Party_Find_Info.dungeon == key;
	elseif (level == 3) then
		return Party_Find_Info.dungeon == upLevelKey
		and
		Party_Find_Info.mode == key;
	end
end

function FP_DropDownMenuFindDungeon_Initialize(frame, level)
	FP_DropDownMenuDungeon_Initialize(
		self,
		level,
		{},
		FP_FindDungeonSelected,
		DropDownMenuFindDungeonCheck
	);
end

local inputEditBox;

function FP_DropDownMenuEditDungeon_Initialize(frame, level)
	local info = {};
	local menuValue = UIDROPDOWNMENU_MENU_VALUE;
	info.notCheckable = true;
	--info.keepShownOnClick = true;

	if (level == 2) then
		info.text = "기본값 불러오기";
		info.func = FP_LoadDefaultDungeonList;
		info.hasArrow = false;
		info.notCheckable = true;
		UIDropDownMenu_AddButton(info, level);

		-- 한줄 비움
		info.text = "";
		info.disabled = true;
		UIDropDownMenu_AddButton(info, level);
		info.disabled = false;
	end

	if (level > 2 and not menuValue["command"]) then
		if (inputEditBox) then inputEditBox:Hide(); end

		if (level == 3) then
			info.text= "<---"..menuValue["Zone"].." 삭제";
		elseif (level == 4) then
			info.text= "<---"..menuValue["Dungeon"].." 삭제";
		elseif (level == 5) then
			info.text= "<---"..menuValue["Alias"].." 삭제";
		end
		info.disabled = false;
		info.hasArrow = false;
		info.func = FP_RemoveDungeonList;
		info.level = level;
		info.value = {
			["command"] = "remove",
			["Zone"] = menuValue["Zone"],
			["Dungeon"] = menuValue["Dungeon"],
			["Alias"] = menuValue["Alias"],
			["level"] = level
		}
		UIDropDownMenu_AddButton(info, level);
		info.func = nil;

		if (level < 5) then
		-- 한줄 비움
			info.text = "";
			info.disabled = true;
			info.hasArrow = false;
			UIDropDownMenu_AddButton(info, level);
			info.disabled = false;
		end
	end

	-- 레벨별 메뉴 제목
	if (level == 2) then
		info.text = "지역 구분";
	elseif (level == 3) then
		info.text = "던전 이름";
	elseif (level == 4) then
		info.text = "던전 별명";
	end
	if (level < 5 and not menuValue["command"]) then
		info.isTitle = true;
		info.justifyH = "CENTER";
		UIDropDownMenu_AddButton(info, level);
		info.isTitle = false;
		info.justifyH = nil;
	end
	info.isTitle = false;

	-- 각 레벨별 추가 메뉴
	if (level < 5  and not menuValue["command"]) then
		-- 한줄 비움
		info.text = "------------------";
		info.isTitle = true;
		info.justifyH = "CENTER";
		UIDropDownMenu_AddButton(info, level);
		info.isTitle = false;
		info.justifyH = nil;

		info.disabled = false;
		info.text= "항목 추가";
		info.hasArrow = true;
		info.value = {
			["Option"] = "던전 편집",
			["command"] = "add",
			["Zone"] = menuValue["Zone"],
			["Dungeon"] = menuValue["Dungeon"],
			["Alias"] = menuValue["Alias"],
			["level"] = level
		}
		UIDropDownMenu_AddButton(info, level);

		-- 한줄 비움
		info.text = "";
		info.disabled = true;
		info.hasArrow = false;
		UIDropDownMenu_AddButton(info, level);
		info.disabled = false;

		info.func = nil;
		info.hasArrow = true;
	end

	-- 던전 리스트출력
	if (level == 2) then
		menuValue["subarray"] = FP_DUNGEON_LIST;
	end

	if (level > 1 and level < 6) then
		if (menuValue["command"] == "add") then
			info.text ="                            ";
			info.hasArrow = false;
			UIDropDownMenu_AddButton(info, level);

			local tempParent = getglobal("DropDownList"..level.."Button1");
			if (not inputEditBox) then
				inputEditBox = CreateFrame("EditBox", nil, tempParent , "InputBoxTemplate");
				inputEditBox:SetScript("OnEnterPressed", FP_AddDungeonList);
			end
			inputEditBox:SetParent(tempParent);
			inputEditBox:ClearAllPoints();
			inputEditBox:SetAllPoints(tempParent);
			inputEditBox:Show();
			inputEditBox:SetFocus();
		elseif (type(menuValue["subarray"]) == "table") then
			local subarray = menuValue["subarray"];
			local idx, v;
			while(true) do
				idx,v = next(subarray, idx);
				if (not idx) then break; end

				if (type(idx) == "number") then
					info.text = v;
				else
					info.text = idx;
				end
				info.value = {};
				info.value.subarray = v;
				info.level = level;

				if (not menuValue.Alias) then
					if (not menuValue.Dungeon) then
						if (not menuValue.Zone) then
							info.value.Zone = idx;
						else
							info.value.Dungeon = idx;
							info.value.Zone = menuValue.Zone;
						end
					else
						info.value.Alias = v;
						info.value.Zone = menuValue.Zone;
						info.value.Dungeon = menuValue.Dungeon;
					end
				end

				UIDropDownMenu_AddButton(info, level);
			end
		end
	end
end

function FP_DropDownMenuDungeon_Initialize(frame, level, info, targetFunc, checkFunc)
	level = level or 1;
	if (not checkFunc) then checkFunc = function() return false; end end

	if (level == 1) then
		info.hasArrow = true; -- creates submenu
		info.notCheckable = true;
		info.func = nil;

		for key, subarray in pairs(FP_DUNGEON_LIST) do
			info.text = key;
			info.value = {
				["Zone"] = key,
				["level"] = level
			};
			UIDropDownMenu_AddButton(info, level);
		end -- for key, subarray
	end -- if level 1

	if (level == 2) then
		-- getting values of first menu
		local Level1_Key = UIDROPDOWNMENU_MENU_VALUE["Zone"];
		-- 공격대 순서대로 정렬을 위한 수정 - by 영원이란
		local raid_ckeck = false;
		local raid_count = 0;
		if (Level1_Key == "공격대") then
			for k, v in pairs(FP_DUNGEON_LIST["공격대"]) do
				raid_count = raid_count + 1;
			end
			if (raid_count == 24) then
				subarray = FP_RAID_LIST;
				raid_check = true;
			else
				subarray = FP_DUNGEON_LIST["공격대"];
				raid_check = false;
			end
		else
			subarray = FP_DUNGEON_LIST[Level1_Key];
			raid_check = false;
		end
		if (subarray) then
			if (raid_check) then
				info.hasArrow = true;
				info.func =targetFunc;

				for key, subsubarray in pairs(subarray) do
					info.text = subsubarray;
					info.checked = checkFunc(level, subsubarray);
					info.value = {
						["Zone"] = Level1_Key,
						["Dungeon"] = subsubarray,
						["level"] = level
					};
					UIDropDownMenu_AddButton(info, level);
				end -- for key,subsubarray
			else
				-- 아제로스 분류는 난이도 선택이 없으므로 삭제, 공격대 분류 상위로 이동 by 영원이란
				info.hasArrow = (Level1_Key == "아웃랜드" or Level1_Key == "노스렌드" or Level1_Key == "공격대"); -- no submenues this time
				info.func =targetFunc;

				for key, subsubarray in pairs(subarray) do
					--info.notCheckable = (Level1_Key == "아웃랜드");
					info.text = key;
					info.checked = checkFunc(level, key);
					info.value = {
						["Zone"] = Level1_Key,
						["Dungeon"] = key,
						["level"] = level
					};
					UIDropDownMenu_AddButton(info, level);
				end -- for key,subsubarray
			end
		end
	end -- if level 2

	if (level == 3) then
		if (inputEditBox) then inputEditBox:Hide(); end
		local Level1_Key = UIDROPDOWNMENU_MENU_VALUE["Zone"];
		local Level2_Key = UIDROPDOWNMENU_MENU_VALUE["Dungeon"];
		info.func = targetFunc;

		--목록 던전 순서를 맞추기 위해 배열을 하나 더 만듬 by 영원이란
		--for key, subarray in pairs(FP_DUNGEON_MODE) do
		for key, subarray in pairs(FP_DUNGEON_MODE2) do
			--info.text = Level2_Key.." "..key;
			info.text = Level2_Key.." "..subarray;
			--info.checked = checkFunc(level, key, Level2_Key);
			info.checked = checkFunc(level, subarray, Level2_Key);
			info.value = {
				["Zone"] = Level1_Key,
				["Dungeon"] = Level2_Key,
				--["Mode"] = key,
				["Mode"] = subarray,
				["level"] = level
			};
			UIDropDownMenu_AddButton(info, level);
		end
	end
end

function FP_DropDownMenuClass_Initialize(frame, level)
	local info = UIDropDownMenu_CreateInfo();

	info.func = FP_ClassSelected;

	for key, subarray in pairs(FP_CLASS_LIST) do
		info.text = key;
		info.value = key;
		info.checked = (key == FP_Filter_Class);
		UIDropDownMenu_AddButton(info);
	end -- for key, subarray
end

function FP_DropDownMenuOption_Initialize(frame, level)
	level = level or 1;

	if (level == 1) then
	         for idx, tbl in ipairs(FP_OPTION_LIST) do
			local info = UIDropDownMenu_CreateInfo();
			info.notCheckable = true;
			name = next(tbl);

			info.text = name;
			info.hasArrow = name ~= ""; -- creates submenu
			info.disabled = name == "";
			info.hasColorSwatch = false;
			info.hasOpacity = false;
			info.func = nil;

			info.value = {
				["Option"] = name,
				["subarray"] =FP_OPTION_LIST[idx][name],
			};
			if (name == "창 색상 편집") then
				info.hasArrow = false;
				info.hasColorSwatch = true;
				info.hasOpacity = true;
				info.r = FP_Options.color.r;
				info.g = FP_Options.color.g;
				info.b = FP_Options.color.b;
				info.opacity = FP_Options.color.opacity;
				info.func = UIDropDownMenuButton_OpenColorPicker
				info.swatchFunc = FP_ColorSelected;
				info.opacityFunc = FP_ColorSelected;
				info.cancelFunc = FP_ColorSelected;
			end

			if (name == "귀속던전 제외") then
				info.hasArrow = false;

				if (FP_Options[FP_OPTION_NAME[name]]) then
					info.notCheckable = nil;
					info.checked = true;
				end
				info.func = FP_OptionSelected;
			end
			FP_Debug("option name : "..name);
			if (name == "ESC로 창 닫기") then
				info.hasArrow = false;

				if (FP_Options[FP_OPTION_NAME[name]]) then
					info.notCheckable = nil;
					info.checked = true;
				end
				info.func = FP_OptionSelected;
			end

			UIDropDownMenu_AddButton(info, level);
		end -- for key, subarray
	end -- if level 1

	if (level == 2) then
		local info = UIDropDownMenu_CreateInfo();
		local Level1_Key = UIDROPDOWNMENU_MENU_VALUE["Option"];
		local opName = FP_OPTION_NAME[Level1_Key];
		if (Level1_Key == "던전 편집") then
			FP_DropDownMenuEditDungeon_Initialize(frame, level);
		else
			subarray = UIDROPDOWNMENU_MENU_VALUE["subarray"];
			info.func =FP_OptionSelected;

			for i=1, table.getn(subarray) do
				local item = subarray[i];
				info.text = item;
				info.value = {
					["Option"] = Level1_Key,
					["Value"] = item,
				};

				if (opName == "channel") then
					info.checked = FP_Options[opName][item];
	--				info.keepShownOnClick = true;
				else
					info.checked = (item == tostring(FP_Options[opName]));
				end

				UIDropDownMenu_AddButton(info, level);
			end -- for key,subsubarray
		end
	end -- if level 2

	if (level > 2) then
		FP_DropDownMenuEditDungeon_Initialize(frame, level);
	end

end

function FP_WhTextSaveByOnEnter()
	FP_UserDefinedWhMsg = msg;
	FP_Debug("FP_WhTextSaveByOnEnter");
end

function FP_OnLoad()
	FP_InviteControlFrame:RegisterEvent("VARIABLES_LOADED");
	FP_InviteControlFrame:RegisterEvent("ADDON_LOADED");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_SAY");
	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_CHANNEL");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_WHISPER");
	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_SYSTEM");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_CHANNEL_LEAVE");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_CHANNEL_JOIN");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_CHANNEL_LIST");
--	FP_InviteControlFrame:RegisterEvent("RAID_ROSTER_UPDATE");
--	FP_InviteControlFrame:RegisterEvent("PARTY_MEMBERS_CHANGED");
--	FP_InviteControlFrame:RegisterEvent("PARTY_MEMBER_ENABLE");
	FP_InviteControlFrame:RegisterEvent("WHO_LIST_UPDATE");
--	FP_InviteControlFrame:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE");
	FP_InviteControlFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
end

function FP_OnEvent(event)
	if (event=="ADDON_LOADED") then
		ADDON_LOADED();
	end
	if (event=="VARIABLES_LOADED") then
		FP_InviteControlFrame:UnregisterEvent("VARIABLES_LOADED");
		FP_Init();
	end
	if (not FP_Options or not FP_Options.activated) then return; end

	if (event == "CHAT_MSG_CHANNEL" and FP_Options.channel[arg9]) then
		FP_AddList(arg2, arg1);
	elseif (event == "CHAT_MSG_SYSTEM" or event == "WHO_LIST_UPDATE") then
		if (GetNumWhoResults() > 0 and ShouterSelected) then
			for i=1,GetNumWhoResults() do
				local charname, guildname, level, race, class, zone = GetWhoInfo(i);
				if (ShouterSelected.name == charname) then
					ShouterSelected.class = class;
					ShouterSelected.level = level;
					FP_Refresh(true);
					break;
				end
			end
		end
--	elseif (event == "CHAT_MSG_CHANNEL_NOTICE") then
--		FP_GetChannels();
	elseif (event == "PLAYER_ENTERING_WORLD") then
		User_Realm = GetRealmName();
		User_Faction = UnitFactionGroup("player");
	end
end

-- Looking For Group 자동 추가 메소드(예정)
function FP_registLFG(dungeon, mode)

end

function FP_OnUpdate()
	if (not FP_Options.activated) then return; end

	local time = GetTime() * 1000;
	local elapsed =  time - valdating_timer;
	if (elapsed > 1000 and table.getn(FP_Datas) > 0) then
		local i=1;
		while(i <= table.getn(FP_Datas)) do
			FP_Datas[i].time = FP_Datas[i].time + 1;

			if (FP_Datas[i].time > FP_Options.valid) then
				FP_RemoveList(FP_Datas[i].name);
			else
				i = i +1;
			end
		end
		valdating_timer = time;

		FP_Refresh(true);
	end

	if (Party_Find_Info.announcing == true) then
		FP_Debug("time = "..tostring(time).."  timer ="..tostring(announce_timer));
		elapsed = time - announce_timer;

		FP_Debug(tostring(elapsed));
		if (elapsed > FP_Options.interval * 1000) then
			FP_Announce();
			announce_timer = time;
		end
	end
end

function FP_Debug(msg)
	if(debugSwitch) then DEFAULT_CHAT_FRAME:AddMessage(tostring(msg)); end
end

SLASH_FINDPARTY1 = "/FP";
SLASH_FINDPARTY2 = "/fp";
SLASH_FINDPARTY3 = "/findparty";

SlashCmdList["FINDPARTY"] = function(msg)
	FP_Debug("SlashCmdList");
	local _, _, command, args = string.find(msg, "(%S+)%s?(.*)");

	FP_Frame:Show();

end

function ADDON_LOADED()
	FP_InviteControlFrame:UnregisterEvent("ADDON_LOADED")
end