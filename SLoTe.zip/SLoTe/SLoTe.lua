﻿CreateFrame("Frame", "SLT", UIParent)   
SLT:RegisterEvent("LOOT_OPENED")   
SLT:RegisterEvent("ADDON_LOADED")
SLT:RegisterEvent("UI_ERROR_MESSAGE")
SLT:RegisterEvent("CHAT_MSG_LOOT")
SetCVar('AutoLootDefault', 1)
Activation = 0
local initActivation = Activation;   
loaded = 0
BINDING_HEADER_ScrollingLootText = "Scrolling Loot Text";
BINDING_NAME_SLoTe = "On/Off Function";

function SLT_OnEvent()
	if event == "ADDON_LOADED" and loaded == 0 then
		if Activation == 0 then
			ChatFrame1:AddMessage("|cFF1A16CESLoTe initialized, it is |cFFD80000Deactivated|cFF1A16CE, enter |cFFFFFFFF*/SLoTe* |cFF1A16CEto |cFF25C510Activate |cFF1A16CEit.|r")
			loaded = 1   
		elseif Activation == 1 then
			ChatFrame1:AddMessage("|cFF1A16CESLoTe initialized, it is |cFF25C510Activated|cFF1A16CE. enter |cFFFFFFFF*/SLoTe* |cFF1A16CEto |cFFD80000Deactivate |cFF1A16CEit.|r")
			loaded = 1
		end
	end

if event == "UI_ERROR_MESSAGE" and arg1 == ERR_INV_FULL then
--invisfull = 1
CombatText_AddMessage("INVENTORY IS FULL", CombatText_StandardScroll, 1, 0, 0)
end
	if (event == "LOOT_OPENED") and (Activation == 1) then
		LootFrame:SetClampedToScreen(false);
		LootFrame:ClearAllPoints();
		LootFrame:SetPoint("BOTTOMRIGHT", "UIParent", "TOPLEFT", -300, 300);
		local numitems= GetNumLootItems();
			for i = 1, numitems, 1 do
				lootIcon, lootName, lootQuantity, rarity= GetLootSlotInfo(i);
				
				--if invisfull == 1 then
					--CombatText_AddMessage("INVENTORY IS FULL", CombatText_StandardScroll, 1, 0, 0);
					--invisfull = 0
				--end
			local r, g, b, hex = GetItemQualityColor(rarity);
				if lootQuantity >= 2 then
					CombatText_AddMessage("|T".. lootIcon ..":22:22:0:0|t".." "..lootQuantity.." x "..lootName, CombatText_StandardScroll, r, g, b);
				else
					CombatText_AddMessage("|T".. lootIcon ..":22:22:0:0|t".." "..lootName, CombatText_StandardScroll, r, g, b);
				--end
				end
			end
	end

end

function SLT_Command()
	if Activation == 0 then
		Activation = 1
		ChatFrame1:AddMessage("|cFF25C510SLoTe activated.|r")
	else
		Activation = 0
		ChatFrame1:AddMessage("|cFFD80000SLoTe deactivated.|r")
	end
end
SlashCmdList["SLT"] = SLT_Command;
SLASH_SLT1 = "/SLoTe";
 
SLT:SetScript("OnEvent", SLT_OnEvent) 