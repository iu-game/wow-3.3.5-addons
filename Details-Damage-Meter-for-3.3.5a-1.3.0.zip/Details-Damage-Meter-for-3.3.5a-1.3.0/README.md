# Details-Damage-Meter-for-3.3.5a
Details Damage Meter backported for World of Warcraft 3.3.5a Wrath of the Lich King (WotLK).

# Some information
Feel free to ask any questions (and maybe features? :>).  
Would love to hear some feedback from you.  
Now go and flex before rest of your raid :P

# Installation

1. Download **[Latest Version](https://github.com/Kowson/Details-Damage-Meter-for-3.3.5a/releases/latest)**
2. Unpack the ZIP file
3. Open the folder "Details-Damage-Meter-for-3.3.5a-(#.#.##)"
4. Copy (or drag and drop) all folders into your WoW-Directory\Interface\AddOns
5. Restart WoW
6. Might need to use /details reinstall if something doesn't work.

## In order to have working boss encounters you also need to have installed [DBM-for-Details](https://github.com/Kowson/DBM-for-Details)
1. Download **[Latest Version](https://github.com/Kowson/DBM-for-Details/releases/latest)**
2. Unpack the ZIP file
3. Open the folder "DBM-for-Details-(#.#.##)"
4. Copy (or drag and drop) all folders into your WoW-Directory\Interface\AddOns
5. Restart WoW

# Screenshots
https://imgur.com/a/5dWJBxl

