local L = LibStub("AceLocale-3.0"):NewLocale("Details_RaidInfo-EoE", "enUS", true) 

if (not L) then
	return 
end 

L["PLUGIN_NAME"] = "Raid Info Eye of Eternity"
L["STRING_RAID_NAME"] = "Eye of Eternity"

L["BOSS_MALYGOS"] = "Malygos"