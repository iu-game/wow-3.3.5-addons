if GetLocale() ~= "esES" then return end
local L = DBM_SpellsUsed_Translations



L.TabCategory_SpellsUsed	= "Cd de Echizo/Habilidad"
L.AreaGeneral 			= "Opciones Generales"
L.Enable 			= "Habilitar cdsEnable cooldown timers"
L.Show_LocalMessage 		= "Mostrar mensaje local cuando casteas"
L.Enable_inRaid			= "Mostrar cds solo de miembros de la raid"
L.Enable_inBattleground		= "Mostrar cds en batallas"
L.Enable_Portals		= "Mostrar duracion de portales"
L.Reset				= "Reinciar de fabrica"
L.Local_CastMessage 		= "Cast detectado: %s"
L.AreaAuras 			= "Configurar hechizos/habilidades"
L.SpellID 			= "ID de Hechizo"
L.BarText 			= "Texto de barra (defecto: %spell: %player)"
L.Cooldown 			= "Cooldown"
L.Error_FillUp			= "Por favor, rellena los campos antes de a�adir otro"




