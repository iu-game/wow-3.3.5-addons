# DisplayDungeon
    WoW WotLK 3.3.5a AddOn

# Notice:
    This AddOn might work on older on newer versions of WoW. Tested on 3.3.5a

# Description:
    This simple AddOn shows small icons under a minimap
    which shows current RDF queue status.
    Example: "Dungeon: 3/5"
    You no longer have to hover queue icon to check RDF status!

# Config:
    Check "DisplayDungeon_Config.lua" file to configure position of the widget.

# Screenshot:
![Screenshot](https://i.imgur.com/J6jCcHs.png)

# Installation:
    Drop "DisplayDungeon" folder inside your AddOns directory.

# License:
    You have no rights to republish this AddOn as your own.
    You can edit it as you like it.
    If you want to republish it, contact me first.
    Always take credits ;)
